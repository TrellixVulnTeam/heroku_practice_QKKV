import requests
import pandas as pd
import random
import json

INFERENCE_URL = 'http://127.0.0.1:5000/'
X_TEST = pd.read_csv("d://downloads//X_test.csv")


def predict_single():
    print('Predicting a single value using GET:')
    url = INFERENCE_URL + 'predict_single'
    for i in range(5):
        params = dict(X_TEST.iloc[random.randint(0, len(X_TEST)), :])
        pred = requests.get(url, params=params)
        print(f'The prediction for these parameters- {params}'
              f' is- {pred.text}')

    print()
    print()


def predict_multiple():
    print('Predicting multiple values using POST:')
    url = INFERENCE_URL + 'predict_multiple'

    rand = random.randint(0, len(X_TEST))
    len_preds = 5
    preds = X_TEST.iloc[rand:(rand+len_preds), :]

    my_json = [[] for _ in range(len(preds))]
    for i in range(len(preds)):
        my_json[i].append(dict(preds.iloc[i, :]))

    print('Predicting these values:')
    print(my_json)
    print()
    pred = requests.post(url, json=json.dumps(my_json))
    print("Predictions for these values (added a 'prediction' value for the JSON")
    print(pred.json())


if __name__ == '__main__':
    predict_single()
    predict_multiple()